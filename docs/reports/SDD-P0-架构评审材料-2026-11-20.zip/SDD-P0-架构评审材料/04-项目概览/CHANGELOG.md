# Changelog

所有重要变更将记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [未发布]

### 新增
- 项目初始化
- P0 总体架构设计（In Review）
- 2026-11-20：补齐 platform / security / testing 三篇架构文档
- 2026-11-20：P0 接管盘点报告、P0 整改报告、P0-001 整改任务书入库

### 变更

### 修复

### 删除
